#ifndef SLEEPMGR_H_
#define SLEEPMGR_H_

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif


void sleepmgr_init(void);


void sleepmgr_sleep_seconds(uint32_t seconds);


uint8_t sleepmgr_last_wakeup_was_rtc(void);

#ifdef __cplusplus
}
#endif

#endif /* SLEEPMGR_H_ */
