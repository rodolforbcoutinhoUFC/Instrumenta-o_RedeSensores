

#include "stm32f1xx.h"
#include <stdint.h>


void sleepmgr_init(void);
void sleepmgr_sleep_seconds(uint32_t seconds);
uint8_t sleepmgr_last_wakeup_was_rtc(void);

extern void SystemClock_Config(void);

static volatile uint8_t g_rtc_alarm_fired = 0;


static uint32_t rtc_get_counter(void)
{
    uint32_t high = RTC->CNTH;
    uint32_t low  = RTC->CNTL;
    return (high << 16) | low;
}

static void rtc_wait_write_ready(void)
{
    while (!(RTC->CRL & RTC_CRL_RTOFF)) {
    }
}

static void rtc_enter_config(void)
{
    rtc_wait_write_ready();
    RTC->CRL |= RTC_CRL_CNF;
}

static void rtc_exit_config(void)
{
    RTC->CRL &= ~RTC_CRL_CNF;
    rtc_wait_write_ready();
}

static void rtc_set_prescaler_1hz_lsi(void)
{
    /* LSI ~ 40 kHz -> PRL = 39999 -> ~1 Hz */
    rtc_enter_config();
    RTC->PRLH = 0;
    RTC->PRLL = 39999;
    rtc_exit_config();
}

static void rtc_set_alarm(uint32_t alarm_value)
{
    rtc_enter_config();
    RTC->ALRH = (alarm_value >> 16) & 0xFFFF;
    RTC->ALRL = (alarm_value) & 0xFFFF;
    rtc_exit_config();
}


static inline void rtc_alarm_isr_common(void)
{
    EXTI->PR = EXTI_PR_PR17;
    RTC->CRL &= ~(RTC_CRL_ALRF);
    g_rtc_alarm_fired = 1;
}


void RTC_Alarm_IRQHandler(void) { rtc_alarm_isr_common(); }
void RTCAlarm_IRQHandler(void)  { rtc_alarm_isr_common(); }


void sleepmgr_init(void)
{
    RCC->APB1ENR |= RCC_APB1ENR_PWREN | RCC_APB1ENR_BKPEN;

    PWR->CR |= PWR_CR_DBP;

    RCC->CSR |= RCC_CSR_LSION;
    while (!(RCC->CSR & RCC_CSR_LSIRDY)) {
    }

    RCC->BDCR &= ~RCC_BDCR_RTCSEL;
    RCC->BDCR |= RCC_BDCR_RTCSEL_1;

    RCC->BDCR |= RCC_BDCR_RTCEN;

    RTC->CRL &= ~RTC_CRL_RSF;
    while (!(RTC->CRL & RTC_CRL_RSF)) {
    }

    rtc_set_prescaler_1hz_lsi();

    RTC->CRH |= RTC_CRH_ALRIE;

    EXTI->IMR  |= EXTI_IMR_MR17;
    EXTI->RTSR |= EXTI_RTSR_TR17;
    EXTI->PR    = EXTI_PR_PR17;

    NVIC_SetPriority(RTC_Alarm_IRQn, 2);
    NVIC_EnableIRQ(RTC_Alarm_IRQn);

    RTC->CRL &= ~(RTC_CRL_ALRF);
    g_rtc_alarm_fired = 0;
}


static void sleepmgr_prepare_for_stop(void)
{
    SysTick->CTRL = 0;



    if (RCC->APB1ENR & RCC_APB1ENR_USART2EN) {
        USART2->CR1 &= ~USART_CR1_UE;
    }

    if (RCC->APB1ENR & RCC_APB1ENR_I2C2EN) {
        I2C2->CR1 &= ~I2C_CR1_PE;
    }

    if (RCC->APB2ENR & RCC_APB2ENR_ADC1EN) {
        ADC1->CR2 &= ~ADC_CR2_ADON;
    }

    if (RCC->APB2ENR & RCC_APB2ENR_SPI1EN) {
        SPI1->CR1 &= ~SPI_CR1_SPE;
    }


    GPIOA->CRL &= ~(
        (0xF << (2*4)) |  /* PA2 */
        (0xF << (5*4)) |  /* PA5 */
        (0xF << (6*4)) |  /* PA6 */
        (0xF << (7*4))    /* PA7 */
    );


    GPIOB->CRH &= ~(
        (0xF << ((10-8)*4)) | /* PB10 */
        (0xF << ((11-8)*4))   /* PB11 */
    );


    RCC->APB1ENR &= ~(RCC_APB1ENR_USART2EN | RCC_APB1ENR_I2C2EN);
    RCC->APB2ENR &= ~(RCC_APB2ENR_ADC1EN | RCC_APB2ENR_SPI1EN);

	#ifdef FLASH_ACR_SLEEP_PD
    	FLASH->ACR |= FLASH_ACR_SLEEP_PD;
#endif
}

static void sleepmgr_restore_after_stop(void)
{

    RCC->APB1ENR |= (RCC_APB1ENR_USART2EN | RCC_APB1ENR_I2C2EN);
    RCC->APB2ENR |= (RCC_APB2ENR_ADC1EN  | RCC_APB2ENR_SPI1EN);

}


void sleepmgr_sleep_seconds(uint32_t seconds)
{
    g_rtc_alarm_fired = 0;

    uint32_t now = rtc_get_counter();
    rtc_set_alarm(now + seconds);

    __enable_irq();

    PWR->CR |= PWR_CR_CWUF;

    RTC->CRL &= ~(RTC_CRL_ALRF);
    EXTI->PR = EXTI_PR_PR17;
    NVIC_ClearPendingIRQ(RTC_Alarm_IRQn);

    sleepmgr_prepare_for_stop();

    SCB->SCR |= SCB_SCR_SLEEPDEEP_Msk;
    PWR->CR |= PWR_CR_LPDS;

    __WFI();

    SCB->SCR &= ~SCB_SCR_SLEEPDEEP_Msk;

    SystemClock_Config();

    sleepmgr_restore_after_stop();
}


uint8_t sleepmgr_last_wakeup_was_rtc(void)
{
    return g_rtc_alarm_fired;
}
