
#include "stm32f1xx.h"
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include "nrf24.h"
#include "sleep.h"
#include "sensors.h"


typedef struct __attribute__((__packed__)) {
    uint8_t  board_id;
    float    temperature;
    float    humidity;
    uint16_t adc_raw;
} SensorData_t;


static uint8_t board_id = 06;
static AHT_Data_t   sensor_data;
static SensorData_t tx_data;
static char         tx_buffer[128];
static uint16_t     ldr_adc_value;

static NRF24_t radio;

static uint8_t GW_ADDR[5] = {0xE7,0xE7,0xE7,0xE7,0xE7};  //endereço do gateway

void SystemClock_Config(void);
static void GPIO_Init_Manual(void);
static void USART2_Init_Manual(void);
void UART_Transmit_String(const char *str);


#ifndef CONFIG
#define CONFIG 0x00
#endif


// parte do wakeup
#define NRF24_PWR_UP   (1U << 1)
#define NRF24_PRIM_RX  (1U << 0)

#define NRF_CSN_PORT GPIOA
#define NRF_CSN_PIN  3
#define NRF_CE_PORT  GPIOA
#define NRF_CE_PIN   4


static inline void nrf_csn_hi(void) { NRF_CSN_PORT->BSRR = (1U << NRF_CSN_PIN); }
static inline void nrf_csn_lo(void) { NRF_CSN_PORT->BSRR = (1U << (NRF_CSN_PIN + 16)); }

static inline void nrf_ce_lo(void)  { NRF_CE_PORT->BSRR  = (1U << (NRF_CE_PIN + 16)); }
static inline void nrf_ce_hi(void)  { NRF_CE_PORT->BSRR  = (1U << NRF_CE_PIN); }

static void nrf24_power_down(NRF24_t *dev)
{
    Nrf24_ceLow(dev);
    Nrf24_configRegister(dev, CONFIG, 0x08);
}

static void NRF_Gateway_TX_Setup(void)
{
    Nrf24_init(&radio);

    Nrf24_config(&radio, 0x5A, 16);      // canal 0x5A, payload 16
    Nrf24_setTADDR(&radio, GW_ADDR);     // TX_ADDR e RX_ADDR_P0 (para auto-ack)

    Nrf24_SetSpeedDataRates(&radio, 2);  // 2 = 250kbps
    Nrf24_SetOutputRF_PWR(&radio, 3);    // 3 = PA_MAX

    Nrf24_setRetransmitDelay(&radio, 10);
    Nrf24_setRetransmitCount(&radio, 10);

    Nrf24_configRegister(&radio, EN_AA, 0x01);

    UART_Transmit_String("NRF MiRF: TX setup OK\r\n");
}
static void gpio_lowpower_spi_pins(void)
{
    // Desliga SPI1
    SPI1->CR1 &= ~SPI_CR1_SPE;
    RCC->APB2ENR &= ~RCC_APB2ENR_SPI1EN;

    // PA5
    GPIOA->CRL &= ~(GPIO_CRL_MODE5 | GPIO_CRL_CNF5);
    // PA6
    GPIOA->CRL &= ~(GPIO_CRL_MODE6 | GPIO_CRL_CNF6);
    // PA7
    GPIOA->CRL &= ~(GPIO_CRL_MODE7 | GPIO_CRL_CNF7);
}

static void nrf24_pins_safe(void)
{
    // CE baixo sempre
    nrf_ce_lo();

    // CSN alto (desseleciona SPI)
    nrf_csn_hi();
}

static void spi1_pins_restore(void)
{
    // Habilita clock do SPI1
    RCC->APB2ENR |= RCC_APB2ENR_SPI1EN | RCC_APB2ENR_IOPAEN | RCC_APB2ENR_AFIOEN;

    // PA5 (SCK) AF-PP 50MHz
    GPIOA->CRL &= ~(GPIO_CRL_MODE5 | GPIO_CRL_CNF5);
    GPIOA->CRL |=  (GPIO_CRL_MODE5_1 | GPIO_CRL_MODE5_0); // 50 MHz
    GPIOA->CRL |=  (GPIO_CRL_CNF5_1);                     // AF push-pull

    // PA7 (MOSI) AF-PP 50MHz
    GPIOA->CRL &= ~(GPIO_CRL_MODE7 | GPIO_CRL_CNF7);
    GPIOA->CRL |=  (GPIO_CRL_MODE7_1 | GPIO_CRL_MODE7_0);
    GPIOA->CRL |=  (GPIO_CRL_CNF7_1);

    // PA6 (MISO) input floating
    GPIOA->CRL &= ~(GPIO_CRL_MODE6 | GPIO_CRL_CNF6);
    GPIOA->CRL |=  (GPIO_CRL_CNF6_0); // input floating

    // (Re)habilita SPI (se seu nrf24.c não fizer isso)
    SPI1->CR1 |= SPI_CR1_SPE;
}

static void ce_csn_restore_outputs(void)
{
    // Garante clock GPIOA
    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN;

    // PA3 (CSN) output PP 2MHz
    GPIOA->CRL &= ~(GPIO_CRL_MODE3 | GPIO_CRL_CNF3);
    GPIOA->CRL |=  GPIO_CRL_MODE3_1; // 2MHz
    // CNF3 = 00 -> GP push-pull

    // PA4 (CE) output PP 2MHz
    GPIOA->CRL &= ~(GPIO_CRL_MODE4 | GPIO_CRL_CNF4);
    GPIOA->CRL |=  GPIO_CRL_MODE4_1;

    // Estados seguros
    nrf_ce_lo();
    nrf_csn_hi();
}

static void reinit_everything(void)
{
    GPIO_Init_Manual();
    USART2_Init_Manual();
    sensors_reinit_after_stop();
    ce_csn_restore_outputs();
    spi1_pins_restore();
    NRF_Gateway_TX_Setup();
}


void SystemClock_Config(void)
{
    volatile uint32_t timeout = 0;

    RCC->CR |= RCC_CR_HSEON;
    timeout = 0;
    while (!(RCC->CR & RCC_CR_HSERDY) && (timeout++ < 0x10000));

    FLASH->ACR &= ~FLASH_ACR_LATENCY;
    FLASH->ACR |= FLASH_ACR_LATENCY_2;

    RCC->CFGR &= ~((uint32_t)(RCC_CFGR_PLLSRC | RCC_CFGR_PLLXTPRE | RCC_CFGR_PLLMULL));
    RCC->CFGR |= (RCC_CFGR_PLLSRC | RCC_CFGR_PLLMULL9);

    RCC->CR |= RCC_CR_PLLON;
    timeout = 0;
    while (!(RCC->CR & RCC_CR_PLLRDY) && (timeout++ < 0x10000));

    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
    RCC->CFGR |= (RCC_CFGR_HPRE_DIV1 | RCC_CFGR_PPRE1_DIV2 | RCC_CFGR_PPRE2_DIV1);

    RCC->CFGR &= ~((uint32_t)RCC_CFGR_SW);
    RCC->CFGR |= RCC_CFGR_SW_PLL;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL);
}

static void GPIO_Init_Manual(void)
{
    RCC->APB2ENR |= RCC_APB2ENR_IOPCEN | RCC_APB2ENR_IOPBEN | RCC_APB2ENR_IOPAEN;
    RCC->APB1ENR |= RCC_APB1ENR_I2C2EN | RCC_APB1ENR_USART2EN;

    /* LED PC13 */
    GPIOC->CRH &= ~(GPIO_CRH_MODE13 | GPIO_CRH_CNF13);
    GPIOC->CRH |= GPIO_CRH_MODE13_1;
    GPIOC->CRH &= ~GPIO_CRH_CNF13;

    /* I2C2 PB10/PB11 AF-OD 2MHz */
    GPIOB->CRH &= ~(GPIO_CRH_MODE10 | GPIO_CRH_CNF10 | GPIO_CRH_MODE11 | GPIO_CRH_CNF11);
    GPIOB->CRH |= (GPIO_CRH_MODE10_1 | GPIO_CRH_MODE11_1);
    GPIOB->CRH |= (GPIO_CRH_CNF10_1 | GPIO_CRH_CNF10_0);
    GPIOB->CRH |= (GPIO_CRH_CNF11_1 | GPIO_CRH_CNF11_0);

    /* USART2 TX PA2 AF-PP 50MHz */
    GPIOA->CRL &= ~(GPIO_CRL_MODE2 | GPIO_CRL_CNF2);
    GPIOA->CRL |= GPIO_CRL_MODE2;
    GPIOA->CRL |= GPIO_CRL_CNF2_1;

    /* ADC1 PB0 (canal 8) analógico */
    GPIOB->CRL &= ~(GPIO_CRL_MODE0 | GPIO_CRL_CNF0);
}

static void USART2_Init_Manual(void)
{
    USART2->BRR = 312;
    USART2->CR1 |= USART_CR1_TE | USART_CR1_UE; /* só TX */
    USART2->CR2 = 0x0000;
    USART2->CR3 = 0x0000;
}

void UART_Transmit_String(const char *str)
{
    for (uint16_t i = 0; i < strlen(str); i++) {
        while (!(USART2->SR & USART_SR_TXE));
        USART2->DR = (uint16_t)str[i];
    }
}

int main(void)
{
	SystemClock_Config();
	GPIO_Init_Manual();
	USART2_Init_Manual();
	sensors_init();
	sleepmgr_init();
	NRF_Gateway_TX_Setup();

    while (1)
    {
    	if (aht10_read(&sensor_data) == SENS_OK) {
    	    ldr_adc_value = ldr_read_raw();

            tx_data.board_id    = board_id;
            tx_data.temperature = sensor_data.temperature;
            tx_data.humidity    = sensor_data.humidity;
            tx_data.adc_raw = ldr_adc_value;

            uint8_t pkt[16];
            memset(pkt, 0, sizeof(pkt));
            memcpy(pkt, &tx_data, sizeof(tx_data));

            Nrf24_send(&radio, pkt);
            if (Nrf24_isSend(&radio, 50)) {
                UART_Transmit_String("TX_OK\r\n");
            } else {
                UART_Transmit_String("TX_FAIL\r\n");
            }

        } else {
            UART_Transmit_String("AHT10 read error\r\n");
        }

        nrf24_power_down(&radio); //desabilita TX/RX imediatamente
        nrf24_pins_safe();        // assegura tx e rx de ruidos
        gpio_lowpower_spi_pins(); //desabilita spi

        sleepmgr_sleep_seconds(60); //RTC Alarm
        reinit_everything(); //restaura


    }
}
