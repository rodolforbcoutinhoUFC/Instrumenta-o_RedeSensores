# Conforto Térmico e Otimização de Alocação com Lógica Fuzzy

**Projeto da disciplina de Instrumentação – Grupo 3**

Universidade Federal do Ceará (UFC) – Campus Quixadá 
Curso de Engenharia de Computação 
2025.2

---

## Visão Geral

Este projeto implementa um sistema inteligente de alocação de alunos em salas de aula baseado em **conforto térmico**. Utilizando dados ambientais (temperatura do ar, temperatura radiante, umidade, velocidade do ar) e as preferências subjetivas dos ocupantes (sensação e desejo térmico), o sistema aplica **Lógica Fuzzy** para gerar uma métrica de **Adequabilidade** (0-100%) para cada combinação usuário‑zona. Com essa informação, algoritmos de otimização (Greedy e Método Húngaro) determinam a melhor distribuição dos alunos, maximizando o conforto médio da turma.

O trabalho foi desenvolvido de forma colaborativa:
- **Grupo 1:** implementação da rede de sensores.
- **Grupo 2:** simulação dos dados ambientais complementares.
- **Grupo 3 (este repositório):** processamento dos dados, modelagem fuzzy e otimização da alocação.

